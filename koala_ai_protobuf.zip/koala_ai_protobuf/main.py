import socket
import time
from typing import Tuple
from protobuf import KoalaAI_G2C_pb2
from protobuf import KoalaAI_C2G_pb2
from google.protobuf.internal import decoder

def ReadVarint(socket) -> Tuple[int, int]:
    buff = socket.recv(1)
    length = 1
    if buff == b'':
        return 0

    while (bytearray(buff)[-1] & 0x80) >> 7 == 1:  # while the MSB is 1
        new_byte = socket.recv(1)
        length = length + 1
        if new_byte == b'':
            raise EOFError("unexpected EOF")
        buff += new_byte

    varint, _ = decoder._DecodeVarint(buff, 0)

    return varint, length

def get_message(socket) -> bytes:
    msg_len_bytes = socket.recv(4)
    msg_len = int.from_bytes(msg_len_bytes, "little")
    print(msg_len)
    checkingCode = socket.recv(1)
    print(int.from_bytes(checkingCode, "little"))
    packageID = socket.recv(4)
    print(int.from_bytes(packageID, "little"))
    command, lengthCommand = ReadVarint(socket)
    print(str(command) + " : " + str(lengthCommand))
    length = msg_len - (len(checkingCode) + len(packageID) + lengthCommand)
    data = socket.recv(length)
    # print(data)
    return data

def send_message(msg):
    checkingCode = 123
    packageID = 1
    command = KoalaAI_C2G_pb2.CMD2G.CMD2G_A_I_SERVER_MESSAGE

    mianData = (checkingCode.to_bytes() +
                packageID.to_bytes(4, "little") +
                command.to_bytes() +
                msg)

    sendData = ((len(mianData)).to_bytes(4, "little") + mianData)

    # print(len(mianData))
    c.send(sendData)

HOST = "localhost"  # 127.0.0.1
PORT = 20001
BUFSIZ = 1024
ADDR = (HOST, PORT)

# Create a socket object
c = socket.socket()
# Connect to the remote server
c.connect((HOST, PORT))

MapId = 8
AINum = 2
ChooseMap = False
if ChooseMap:
    data = KoalaAI_C2G_pb2.AIServerMessage()
    data.messageType = KoalaAI_C2G_pb2.AIServerMsgType.CHOOSE_MAP
    data.gameConfig.mapId = MapId

    byte_string = data.SerializeToString()
    send_message(byte_string)
else:
    print("----------Starting sending data for the server----------")
    data = KoalaAI_C2G_pb2.AIServerMessage()
    data.messageType = KoalaAI_C2G_pb2.AIServerMsgType.GAME_GLOBAL_INFO_REQ
    byte_string = data.SerializeToString()
    send_message(byte_string)

    Count = 1
    while True:
        print("----------Parsing the serialized data from the string----------")
        msgData = get_message(c)
        gm = KoalaAI_G2C_pb2.GameMassage()
        gm.ParseFromString(msgData)
        # print(gm.gameState.isGameEnd)
        if gm.messageType == KoalaAI_G2C_pb2.GameMsgType.GAME_GLOBAL_INFO:
            print("----------Receiving global info data for the server----------")
        #     data = KoalaAI_C2G_pb2.AIServerMessage()
        #     data.messageType = KoalaAI_C2G_pb2.AIServerMsgType.CHOOSE_MAP
        #     data.gameConfig.mapId = MapId
        # elif gm.messageType == KoalaAI_G2C_pb2.GameMsgType.GAME_INFO:
        #     print("----------Receiving game info data for the server----------")
            data = KoalaAI_C2G_pb2.AIServerMessage()
            data.messageType = KoalaAI_C2G_pb2.AIServerMsgType.GAME_INIT_REQ
            data.gameConfig.mapId = MapId
            data.gameConfig.numOfAI = AINum

            # agentInitOption = KoalaAI_C2G_pb2.AgentInitOption()
            # agentInitOption.agentId = 0
            # # agentInitOption.startType = 1
            # # agentInitOption.targetPointLevel = 3
            # agentInitOption.startType = 3
            # agentInitOption.targetPointIndex = 2
            # agentInitOption.startPosition.x = 151.7459259033203
            # agentInitOption.startPosition.y = -17.522720336914062
            # agentInitOption.startPosition.z = 185.327880859375
            #
            # agentInitOption2 = KoalaAI_C2G_pb2.AgentInitOption()
            # agentInitOption2.agentId = 1
            # # agentInitOption2.startType = 1
            # # agentInitOption2.targetPointLevel = 2
            # agentInitOption.startType = 3
            # agentInitOption.targetPointIndex = 3
            # agentInitOption.startPosition.x = 125.05032348632812
            # agentInitOption.startPosition.y = -13.053939819335938
            # agentInitOption.startPosition.z = 101.59249877929688
            #
            # data.gameConfig.agentInitOptions.append(agentInitOption)
            # data.gameConfig.agentInitOptions.append(agentInitOption2)

        elif gm.messageType == KoalaAI_G2C_pb2.GameMsgType.GAME_STATE:
            # if Count == 30:
            #     time.sleep(1)
            if gm.gameState.isGameEnd:
                print("----------Receiving configure data for the server----------")
                # MapId += 1

                data = KoalaAI_C2G_pb2.AIServerMessage()
                data.messageType = KoalaAI_C2G_pb2.AIServerMsgType.GAME_INIT_REQ
                data.gameConfig.mapId = MapId
                data.gameConfig.numOfAI = AINum
            else:
                print("----------Receiving action data for the server----------")
                data = KoalaAI_C2G_pb2.AIServerMessage()
                data.messageType = KoalaAI_C2G_pb2.AIServerMsgType.ACTION_REQ

                action0 = KoalaAI_C2G_pb2.AIActionMessage()
                action0.agentId = 1
                # action0.moveDir.y = -1
                action0.actionsType.append(1)

                action1 = KoalaAI_C2G_pb2.AIActionMessage()
                action1.agentId = 0
                action1.actionsType.append(1)

                # data.actionOfAIs.append(action0)
                # data.actionOfAIs.append(action1)
        byte_string = data.SerializeToString()
        send_message(byte_string)
        print(Count)
        Count += 1
c.close()

